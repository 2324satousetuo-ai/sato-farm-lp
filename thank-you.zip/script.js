(function () {
  'use strict';

  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');

  if (navToggle && nav) {
    navToggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
    });

    nav.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        nav.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  document.querySelectorAll('.inquiry-form').forEach((form) => {
    form.addEventListener('submit', (event) => {
      let valid = true;

      form.querySelectorAll('[required]').forEach((field) => {
        const errorEl = form.querySelector('[data-error-for="' + field.id + '"]');
        const message = field.validity.valueMissing
          ? (document.documentElement.lang === 'en' ? 'This field is required.' : '入力してください。')
          : field.validity.typeMismatch
            ? (document.documentElement.lang === 'en' ? 'Please enter a valid email address.' : '正しいメールアドレスを入力してください。')
            : '';

        field.classList.toggle('error', !!message);
        if (errorEl) {
          errorEl.textContent = message;
        }
        if (message) {
          valid = false;
        }
      });

      if (!valid) {
        event.preventDefault();
      }
    });

    form.querySelectorAll('[required]').forEach((field) => {
      field.addEventListener('input', () => {
        field.classList.remove('error');
        const errorEl = form.querySelector('[data-error-for="' + field.id + '"]');
        if (errorEl) {
          errorEl.textContent = '';
        }
      });
    });
  });

  const pagetop = document.querySelector('.pagetop');
  if (pagetop) {
    const togglePagetop = () => {
      pagetop.classList.toggle('is-visible', window.scrollY > 400);
    };

    const scrollToTop = () => {
      const topTarget = document.getElementById('top');
      if (topTarget) {
        topTarget.focus({ preventScroll: true });
      }
      window.scrollTo(0, 0);
    };

    pagetop.addEventListener('click', (event) => {
      event.preventDefault();
      scrollToTop();
    });

    togglePagetop();
    window.addEventListener('scroll', togglePagetop, { passive: true });
  }

  document.querySelectorAll('a[href="#top"]').forEach((link) => {
    if (link.classList.contains('pagetop')) {
      return;
    }
    link.addEventListener('click', (event) => {
      event.preventDefault();
      const topTarget = document.getElementById('top');
      if (topTarget) {
        topTarget.focus({ preventScroll: true });
      }
      window.scrollTo(0, 0);
    });
  });

  const spotsSection = document.querySelector('#spots');
  if (spotsSection) {
    const isEn = document.documentElement.lang === 'en';
    const labels = {
      index: isEn ? 'Jump to a site (number)' : 'サイトを選ぶ（番号）',
      prev: isEn ? 'Previous' : '前へ',
      openNext: isEn ? 'Open next' : '次を開く',
    };

    const entries = [];

    const hanayukariAside = spotsSection.querySelector('.spots__hanayukari');
    const hanayukariLink = spotsSection.querySelector('.spots__hanayukari-link');
    if (hanayukariAside && hanayukariLink) {
      hanayukariAside.id = 'spot-hanayukari';
      entries.push({
        id: 'spot-hanayukari',
        name: isEn ? 'Hanayukari' : '花ゆかり',
        url: hanayukariLink.href,
        element: hanayukariAside,
      });
    }

    spotsSection.querySelectorAll('.spots__item').forEach((item, index) => {
      const link = item.querySelector('.spots__link');
      const nameEl = item.querySelector('.spots__name');
      if (!link || !nameEl) {
        return;
      }

      const id = 'spot-' + String(index + 1).padStart(2, '0');
      item.id = id;
      entries.push({
        id,
        name: nameEl.textContent.trim(),
        url: link.href,
        element: item,
      });
    });

    if (entries.length > 1) {
      const indexLabel = document.createElement('p');
      indexLabel.className = 'spots__index-label';
      indexLabel.textContent = labels.index;

      const indexNav = document.createElement('nav');
      indexNav.className = 'spots__index';
      indexNav.setAttribute('aria-label', labels.index);

      entries.forEach((entry, index) => {
        const indexLink = document.createElement('a');
        indexLink.className = 'spots__index-link';
        indexLink.href = '#' + entry.id;
        indexLink.textContent = String(index + 1);
        indexLink.title = entry.name;
        indexNav.appendChild(indexLink);
      });

      const list = spotsSection.querySelector('.spots__list');
      if (list) {
        list.before(indexNav);
        list.before(indexLabel);
      }

      entries.forEach((entry, index) => {
        const prev = entries[index - 1];
        const next = entries[index + 1];

        const step = document.createElement('div');
        step.className = 'spots__step';

        const prevLink = document.createElement('a');
        prevLink.className = 'spots__step-link spots__step-link--prev';
        if (prev) {
          prevLink.href = '#' + prev.id;
          prevLink.textContent = '← ' + labels.prev + '：' + prev.name;
        } else {
          prevLink.classList.add('is-empty');
          prevLink.textContent = '←';
          prevLink.tabIndex = -1;
        }

        const openNextLink = document.createElement('a');
        openNextLink.className = 'spots__step-link spots__step-link--open';
        if (next) {
          openNextLink.href = next.url;
          openNextLink.textContent = labels.openNext + '：' + next.name + ' →';
        } else {
          openNextLink.classList.add('is-empty');
          openNextLink.textContent = labels.openNext;
          openNextLink.tabIndex = -1;
        }

        step.append(prevLink, openNextLink);

        if (entry.element.classList.contains('spots__hanayukari')) {
          entry.element.appendChild(step);
        } else {
          entry.element.appendChild(step);
        }
      });

      spotsSection.addEventListener('click', (event) => {
        const anchor = event.target.closest('a[href^="#spot-"]');
        if (!anchor) {
          return;
        }

        const targetId = anchor.getAttribute('href').slice(1);
        const target = document.getElementById(targetId);
        if (!target) {
          return;
        }

        event.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });

        spotsSection.querySelectorAll('.spots__index-link').forEach((link) => {
          link.classList.toggle('is-active', link.getAttribute('href') === '#' + targetId);
        });
      });
    }
  }
})();
